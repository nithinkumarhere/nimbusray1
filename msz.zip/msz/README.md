## Contains

### Configuration Details

* WebPack config
* SASS scaffolding
* Routing capability
* Bootstrap 4
* Components
    * App (app scaffolding)
    * Home (homepage)

## Preriquisites

* NodeJS (recommended: 4.1.x)
* NPM (recommended: 3.3.x `sudo npm install -g npm`)

## Install

`npm install`

## Commands

### Web Server

`npm run devserver`

then open `http://localhost:8080/`

### Dump the dev app

`npm run dumpdev`

### Dump the prod (minified) app

`npm run dumpprod`

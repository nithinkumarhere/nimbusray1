import {Component, View} from 'angular2/core';
import {Control, ControlGroup, FormBuilder, Validators} from 'angular2/common';
import {ApiService} from '../shared/api.service';
import { Observable } from 'rxjs/Rx';
import { ViewEncapsulation } from 'angular2/core';
var $ = require('jquery');
window.jQuery = $;


var noUiSlider = require('./nouislider.js');

@Component({
    selector: "test",
    providers: [ApiService],
    styles: [require('!raw!autoprefixer?browsers=last 2 versions!sass!./test.component.scss')],
    template: require('./test.component.html'),
    encapsulation: ViewEncapsulation.None
    
})
export class Test {
      
    form: ControlGroup;

    constructor(formbuilder: FormBuilder, private apiService: ApiService)  {
        
            this.form = formbuilder.group({
                app_name: ['', Validators.required],
                description: ['', Validators.required],
                task: ['', Validators.required],
                gender: ['', Validators.required],
                age_group: ['', Validators.required],
                question_type1: ['', Validators.required],
                question1: ['', Validators.required],
                question_type2: ['', Validators.required],
                question2: ['', Validators.required]
                
            })
            
        }


    ngOnInit() {
        console.log('[Component] test ngOnInit');
       console.log(this.apiService.get('GET/apptest.json')); 
       var slider = document.getElementById('age_group');
  noUiSlider.create(slider, {
   start: [40, 60],
   connect: true,
   step: 10,
   orientation: 'horizontal', // 'horizontal' or 'vertical'
   range: {
     'min': 0,
     'max': 100
   },
   format: wNumb({
     decimals: 0
   })
  });
      
    }

    ngOnDestroy() {
        console.log('[Component] test onDestroy');
    }

    ngOnChanges() {
        console.log('[Component] test onChanges');
    }

    ngDoCheck() {
        console.log('[Component] test doCheck');
    }

    ngAfterContentInit() {
        console.log('[Component] test afterContentInit');
    }

    ngAfterContentChecked() {
        console.log('[Component] test afterContentChecked');
    }

    ngAfterViewInit() {
        console.log('[Component] test afterViewInit');
    }

    ngAfterViewChecked() {
        console.log('[Component] test afterViewChecked');
    }
}

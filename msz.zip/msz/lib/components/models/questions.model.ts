export class Questions {
	questionId: number,
	projectId: number,
	questionTypeId: number,
	question: string
}
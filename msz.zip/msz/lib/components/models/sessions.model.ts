export class Sessions {
	sessionId: number,
	supplyId: number,
	userId: number,
	supplierSessionId: number,
	timeOpened: string,
	timeClosed: string,
	status: number
}
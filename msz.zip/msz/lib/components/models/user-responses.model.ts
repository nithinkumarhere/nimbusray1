export class UserResponses {
	userResponseId: number,
	userId: number,
	questionId: number,
	offerResponseId: number,
	userResponse: string
}
export class Platforms {
	platformId: number,
	platformName: string
}
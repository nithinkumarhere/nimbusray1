export class Customers {
	customerId: number,
	email: string,
	password: string,
	confirmPassword: string,
	firstName: string,
	lastName: string,
	companyName: string,
	status: number
}
export class Projects {
	projectId: number,
	customerId: number,
	platformId: number,
	appId: string,
	appName: string,
	scenario: string,
	task: string,
	status: number
}
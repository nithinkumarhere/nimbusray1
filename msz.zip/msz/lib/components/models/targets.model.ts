export class Targets {
	targetId: number,
	projectId: number,
	numberOfUsers: number,
	ageStart: number,
	ageEnd: number,
	incomeStart: number,
	incomeEnd: number,
	currency: string,
	city: string,
	state: string,
	country: string,
	postalCode: string
}
import {Component, View}    from 'angular2/core';
import {Navbar}             from './navbar/navbar.component';
import {Home}               from './home/index';
import {Report}               from './report/index';
import {Test}               from './test/test.component';
import { MaterializeModule } from 'angular2-materialize';

import {RouteConfig, Route, ROUTER_DIRECTIVES} from 'angular2/router';

@Component({
    selector: "app"
})
@View({
    directives: [Navbar, ROUTER_DIRECTIVES],
    styles: [require('!raw!autoprefixer?browsers=last 2 versions!sass!./index.scss')],
    template: require('./index.html')
})
@RouteConfig([
    new Route({ path: '/', component: Home, name: 'Home' }),
    new Route({ path: '/apptests', component: Test, name: 'Test' }),
    new Route({ path: '/report', component: Report, name: 'Report' }),
   
])
export class App {

    constructor() {

    }

    ngOnInit() {
        console.log('[Component] app running');
    }
}

import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

import { ApiService } from './api.service';

@Injectable()
export class PlatformsService {
	constructor (
		private apiService: ApiService
	) {}

	getAll(): Observable<[string]> {
		return this.apiService.get('/platforms')
			.map(data => data.platforms);
	}
}
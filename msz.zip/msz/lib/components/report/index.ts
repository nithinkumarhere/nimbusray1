import {Component, View} from 'angular2/core';
var $ = require('jquery');
window.jQuery = $;
import './libs.min.js';



@Component({
    selector: "report",
    styles: [require('!raw!autoprefixer?browsers=last 2 versions!sass!./index.scss')],
    template: require('./index.html')
})
export class Report {
    
    

    constructor()  {
            
            
        }

    ngOnInit() {
        console.log('[Component] report ngOnInit');

        //alexa mic initialization

        $(function() {
    function e() {
        $(".overlay").hasClass("visible") && $(".overlay").removeClass("visible"), $(".overlay-contents").removeClass("listening processing")
    }

    function o() {
        e(), $(".overlay").addClass("visible")
    }
    var a = ($(window).width() <= 767, !!(navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia));
    if ($("#support-form").validate(), $(".mobile-btn").on("click", function() {
            $("body").toggleClass("no-overflow"), $("header").toggleClass("open")
        }), $("header li a").each(function() {
            return $("body.homepage").length > 0 || void $('header a[href^="/' + location.pathname.split("/")[1] + '"]').addClass("active")
        }), $(".slider").bxSlider({
            controls: !1,
            pager: !0,
            responsive: !0,
            touchEnabled: !0
        }), !a) return void $(".try-alexa .message").text("We’re sorry your browser doesn’t support Alexa’s web services. Try using Chrome");
    $(".try-alexa").on("click", function() {
        $(".overlay").addClass("visible")
    });
    var n = !1;
    $(".overlay-contents").mousedown(function(e) {
        n = !0, $(this).removeClass("processing"), $(this).addClass("listening")
    }), $(".overlay-contents").bind("mouseup touchend", function(e) {
        n = !0, $(this).removeClass("listening"), $(this).addClass("processing"), window.avs && (window.avs.player.on("ended", o), window.avs.player.on("error", o), window.avs.on("error", o))
    }), $(".overlay").on("click", function() {
        n ? n = !1 : e()
    }), $(document).on("keyup", function(o) {
        27 == o.keyCode && e()
    })
}), $(function() {
    function e() {
        var e = document.cookie,
            o = {};
        cookiearray = e.split("; ");
        for (var a = 0; a < cookiearray.length; a++) name = cookiearray[a].split("=")[0], value = cookiearray[a].split("=")[1], o[name] = value;
        return o
    }! function(o) {
        var a = document.getElementById("mic-button");
        if (a) {
            var n = e(),
                s = n.access;
            if (s) {
                var t = "/api.php",
                    i = {
                        token: s
                    },
                    r = $.ajax({
                        url: t,
                        method: "POST",
                        data: i,
                        headers: {
                            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8"
                        }
                    });
                r.done(function(e) {
                    var e = JSON.parse(e);
                    e && e.access_token && e.access_token && (localStorage.setItem("token", e.access_token), window.avs && (window.avs.setToken(e.access_token), window.avs.requestMic()))
                }), r.fail(function() {
                    console.log("unable to connect to api")
                })
            }
        }
    }()
});



    }

    ngOnDestroy() {
        console.log('[Component] report onDestroy');
    }

    ngOnChanges() {
        console.log('[Component] report onChanges');
    }

    ngDoCheck() {
        console.log('[Component] report doCheck');
    }

    ngAfterContentInit() {
        console.log('[Component] report afterContentInit');
    }

    ngAfterContentChecked() {
        console.log('[Component] report afterContentChecked');
    }

    ngAfterViewInit() {
        console.log('[Component] report afterViewInit');
    }

    ngAfterViewChecked() {
        console.log('[Component] report afterViewChecked');
    }
}

import 'angular2/bundles/angular2-polyfills';
import 'es6-shim';


/// <reference path="./typings/tsd.d.ts" />

import {provide} from 'angular2/core';
import {bootstrap} from 'angular2/platform/browser';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { NouisliderModule } from 'ng2-nouislider';
import {FORM_PROVIDERS} from 'angular2/common';
import {ROUTER_PROVIDERS, LocationStrategy, HashLocationStrategy, APP_BASE_HREF} from 'angular2/router';
import {HTTP_PROVIDERS} from 'angular2/http';
import {App} from './components/index';

bootstrap(App, [
   
    FORM_PROVIDERS,
    HTTP_PROVIDERS,
    ROUTER_PROVIDERS,
    // PathLocationStrategy being the default, we only need to define APP_BASE_HREF
    // provide(APP_BASE_HREF, {useValue: '/'})
    // Here we want to use the # strategy instead:
    provide(LocationStrategy, {useClass: HashLocationStrategy})
]);

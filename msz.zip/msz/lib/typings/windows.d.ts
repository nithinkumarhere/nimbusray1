interface Window { noBullshitBoilerplate: any; }
